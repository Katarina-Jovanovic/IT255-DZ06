import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<h1>{{title}}</h1><br><app-letovi></app-letovi><app-forma></app-forma>',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'WizzRyan';
}
