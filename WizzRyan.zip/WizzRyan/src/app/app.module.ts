import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LetoviComponent } from './letovi/letovi.component';
import { FormaComponent } from './forma/forma.component';

@NgModule({
  declarations: [
    AppComponent,
    LetoviComponent,
    FormaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
