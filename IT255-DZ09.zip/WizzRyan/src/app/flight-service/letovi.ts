export class Letovi{
 cena!:number;
    broj_letova!: number;

}