import { Component } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, FormControl } from '@angular/forms';



@Component({
  selector: 'app-root',
  template: '<app-navbar></app-navbar><h1>{{title}}</h1><br><app-forma></app-forma><app-di></app-di>',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'WizzRyan';

}

