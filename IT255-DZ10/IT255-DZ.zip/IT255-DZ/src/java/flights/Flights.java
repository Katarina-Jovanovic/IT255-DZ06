/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flights;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Katarina
 */
@Entity
@Table(name = "flights")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Flights.findAll", query = "SELECT f FROM Flights f")
    , @NamedQuery(name = "Flights.findByIdLeta", query = "SELECT f FROM Flights f WHERE f.idLeta = :idLeta")
    , @NamedQuery(name = "Flights.findByMestoPolaska", query = "SELECT f FROM Flights f WHERE f.mestoPolaska = :mestoPolaska")
    , @NamedQuery(name = "Flights.findByVremePolaska", query = "SELECT f FROM Flights f WHERE f.vremePolaska = :vremePolaska")
    , @NamedQuery(name = "Flights.findByMestoDolaska", query = "SELECT f FROM Flights f WHERE f.mestoDolaska = :mestoDolaska")
    , @NamedQuery(name = "Flights.findByVremeDolaska", query = "SELECT f FROM Flights f WHERE f.vremeDolaska = :vremeDolaska")})
public class Flights implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_leta")
    private Integer idLeta;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "MestoPolaska")
    private String mestoPolaska;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "VremePolaska")
    private String vremePolaska;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "MestoDolaska")
    private String mestoDolaska;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "VremeDolaska")
    private String vremeDolaska;

    public Flights() {
    }

    public Flights(Integer idLeta) {
        this.idLeta = idLeta;
    }

    public Flights(Integer idLeta, String mestoPolaska, String vremePolaska, String mestoDolaska, String vremeDolaska) {
        this.idLeta = idLeta;
        this.mestoPolaska = mestoPolaska;
        this.vremePolaska = vremePolaska;
        this.mestoDolaska = mestoDolaska;
        this.vremeDolaska = vremeDolaska;
    }

    public Integer getIdLeta() {
        return idLeta;
    }

    public void setIdLeta(Integer idLeta) {
        this.idLeta = idLeta;
    }

    public String getMestoPolaska() {
        return mestoPolaska;
    }

    public void setMestoPolaska(String mestoPolaska) {
        this.mestoPolaska = mestoPolaska;
    }

    public String getVremePolaska() {
        return vremePolaska;
    }

    public void setVremePolaska(String vremePolaska) {
        this.vremePolaska = vremePolaska;
    }

    public String getMestoDolaska() {
        return mestoDolaska;
    }

    public void setMestoDolaska(String mestoDolaska) {
        this.mestoDolaska = mestoDolaska;
    }

    public String getVremeDolaska() {
        return vremeDolaska;
    }

    public void setVremeDolaska(String vremeDolaska) {
        this.vremeDolaska = vremeDolaska;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idLeta != null ? idLeta.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Flights)) {
            return false;
        }
        Flights other = (Flights) object;
        if ((this.idLeta == null && other.idLeta != null) || (this.idLeta != null && !this.idLeta.equals(other.idLeta))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "flights.Flights[ idLeta=" + idLeta + " ]";
    }
    
}
