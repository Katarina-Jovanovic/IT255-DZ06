import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LetoviComponent } from './letovi/letovi.component';
import { FormaComponent } from './forma/forma.component';
import { NavbarComponent } from './navbar/navbar.component';
import { PreporukaComponent } from './preporuka/preporuka.component';
import { ONamaComponent } from './o-nama/o-nama.component';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {path: 'letovi', component: LetoviComponent },
{path: 'preporuka', component: PreporukaComponent },
{path: 'o-nama', component: ONamaComponent}
];


@NgModule({
  declarations: [
    AppComponent,
    LetoviComponent,
    FormaComponent,
    NavbarComponent,
    PreporukaComponent,
    ONamaComponent
  ],
  imports: [
    [RouterModule.forRoot(routes)],
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  exports: [RouterModule]
})
export class AppModule { }
