import { Component } from '@angular/core';

@Component({
  selector: 'app-forma',
  templateUrl: './forma.component.html',
  styleUrls: ['./forma.component.scss']
})
export class FormaComponent {
  dodaj(title: HTMLInputElement, link: HTMLInputElement, mesto:HTMLInputElement, vremeD:HTMLInputElement, mestoD:HTMLInputElement): boolean {
    console.log(`Adding: ${title.value} and vremepolaska: ${link.value} and mesto polaska: ${mesto.value}  and vreme dolaska: ${vremeD.value}  and mesto dolaska: ${mestoD.value}`);
    return false;
  }
}