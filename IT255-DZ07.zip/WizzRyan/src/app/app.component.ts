import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<app-navbar></app-navbar><h1>{{title}}</h1><br><app-letovi></app-letovi><app-forma></app-forma> <app-preporuka></app-preporuka><app-o-nama></app-o-nama>',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'WizzRyan';
}
